/*
 * vga_util.h
 *
 *  Created on: 28 dec 2016
 *      Author: root
 */

#ifndef VGA_UTIL_H_
#define VGA_UTIL_H_
#include <stdio.h>
#include <system.h>
#include <alt_types.h>
#include <io.h>
#include <BeMicro_VGA_IP_Driver.h>
#include <altera_avalon_timer_regs.h>
#include <string.h>
//#include "font8x8_basic.h"

typedef alt_u8 pixel_data;

extern void print_pix(alt_u32 x,alt_u32 y,alt_u32 rgb);
extern void print_hline(alt_u32 x_start,alt_u32 y_start, alt_u32 len,alt_u32 RGB);
extern void print_vline(alt_u32 x_start,alt_u32 y_start, alt_u32 len, alt_u32 RGB);
extern void print_char(alt_u32 x,alt_u32 y,alt_u32 rgb,alt_u32 BG_RGB,char Character);
extern void print_str(alt_u32 x_start, alt_u32 y_start,alt_u32 rgb, const char *str);
extern void print_circle(alt_u32 radie, alt_u32 x_centrum, alt_u32 y_centrum, alt_u32 rgb);
extern void print_empty_circle(alt_u32 radie, alt_u32 x_centrum, alt_u32 y_centrum, alt_u32 rgb);
extern void print_symmetry_dots_circle(alt_u32 x, alt_u32 y, alt_u32 x_centrum, alt_u32 y_centrum, alt_u32 rgb);
extern void clear_screen(alt_u32 rgb);
extern pixel_data read_pixel_ram_int(alt_u32 x_start, alt_u32 y_start);
//void print_line(alt_u32 x_start,alt_u32 y_start,alt_u32 x_slut,alt_u32 y_slut);
extern void print_welcome_screen(void);
extern void draw_sampling_frequecy_sub_screen(void);
extern void high_lite_5Hz_sampling_on_screen(void);
extern void high_lite_1Hz_sampling_on_screen(void);
extern void high_lite_dot2Hz_sampling_on_screen(void);
extern void update_time(unsigned int i);  //Prints the time
extern unsigned int i2bcd(unsigned int i);//utility function for presenting time integer to bcd






#endif /* VGA_UTIL_H_ */
